package com.practice.banking;
import java.util.Scanner;


public class Account {
	
	//Class Variables:
	int balance;
	int previousTransaction;
	String customerName;
	String customerID;

	//Class Constructor:
	//To create constructor type name of class ("Account")
	Account(String cname, String cid) { //Then specify which variables want created in constructor when create new object e.g: cname and cid

		customerName = cname;
		customerID = cid;
	}
	
	//Function for Depositing money:
	void deposit(int amount) { 	//Any time call function "deposit" we specify a specific amount: "int amount"

		if (amount != 0) { //If amount NOT = 0, do *thing* (no else statement because if = 0 nothing needs to be done)
			balance = balance + amount; //If amount NOT = 0, then current balance = current balance + this amount (amount being deposited with this function)
			previousTransaction = amount; //Setting "previousTransaction" = to amount
		}
	}
	
	//Function for Withdraw money:
	void withdraw(int amount) { //When call "withdraw" function, give it certain amount
		
		if (amount != 0) {
			balance = balance - amount; //Subtracting amount from balance
			previousTransaction = -amount; //Setting "prevTrans" variable equal to negative amount (negative (-) version of amount withdrawn)
		}
	}
	
	//Function showing the previous transaction:
	void getPreviousTransaction() {
		
		if (previousTransaction > 0) { //Test whether previous transaction greater than 0
			System.out.println("depsoited: " + previousTransaction); //Show amount deposited 
		} else if (previousTransaction < 0) { //Test whether previous transaction less than 0
			System.out.println("Withdrawn: " + Math.abs(previousTransaction)); //Show withdrawn previous transaction
		} else { //Test whether previous transaction neither > or < 0
			System.out.println("No transaction occured");
		}
	}
	
	//Function calculating interest of current funds after number of years
	void calculateInterest(int years) { //Has one variable; "years"
		
		double interestRate = .0185; //Set % of interest rate
		double newBalance = (balance * interestRate * years) + balance; //New account balance
		System.out.println("The current interest rate is " + (100 * interestRate) + "%"); //Multiply by 100 to get interest rate rather than percentage and concatenate % sign
		System.out.println("After " + years + " years, your balance will be: " + newBalance);
	}
	
	//Function showing main menu:
	//Calls on all other functions build so far
	void showMenu() {
		char option = '\0'; //Create variable "option" which is how choose between different options,
							//of type "char" for character, which placeholder variable '\0'
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in); //Create scanner object because asking for user input
		System.out.println("Welcome, " + customerName + "!");
		System.out.println("Your ID is: " + customerID);
		System.out.println();
		System.out.println("What would you like to do?"); //Give options (below)
		System.out.println();
		System.out.println("A. Check your balance");
		System.out.println("B. Make a deposit");
		System.out.println("C. Make a withdrawl");
		System.out.println("D. View previous transaction");
		System.out.println("E. Calculate interest");
		System.out.println("F. Exit");
		
		//Put all the options (A-F) inside a SWITCH statement inside a DO WHILE loop
		do {
			System.out.println();
			System.out.println("Enter an option  ");
			char option1 = scanner.next().charAt(0); //New variable 'option1' that works with 'option' bellow. Is of type char. 'charAt(0)' means it only takes in first character of word typed
			option = Character.toUpperCase(option1); //So user can enter letter either upper or lower case and wont get error. Converts letter to upper case either way
			System.out.println();
			
			switch(option) {
			//Case 'A' allows the user to check their account balance:
			case 'A' : //Checks balance
				System.out.println("===================================");
				System.out.println("Balance = £" + balance);
				System.out.println("===================================");
				System.out.println();
				break; 
			//Case 'B' allows user to deposit money into account:
			case 'B' : 	
				System.out.println("Enter an amount to deposit: ");
				int amount = scanner.nextInt(); //Create new int called "amount" - save next int inputed by user
				deposit(amount); //Call deposit function with *this* amount
				System.out.println();
				break;
			//Case 'C' allows user to withdraw money:
			case 'C' :
				System.out.println("Enter an amount to withdraw: ");
				int amount2 = scanner.nextInt(); //Save amount withdrawn above into "amount2"
				withdraw(amount2); //Call withdraw function with variable called "amount2"
				System.out.println();
				break;
				
			//Case 'D' allows user to view their most recent transaction:
			case 'D' :
				System.out.println("===================================");
				getPreviousTransaction(); //Call getPrevTrans function
				System.out.println("===================================");
				System.out.println();
				break;
				
			//Case 'E' calculates interest after number of years
			case 'E' :
				System.out.println("Enter how many years of interest: ");
				int years = scanner.nextInt(); //Save years inputed into int years
				calculateInterest(years); //Calculate interest given variable 'years' specified above
				break;
			
			//Case 'F' exit account:
			case 'F' :
				System.out.println("===================================");
				break;
				
			//The default case lets user know they entered an invalid char:
			default:
				System.out.println("Error: invalid option. Enter char A-F");
				break;					
			}	
		//End of DO WHILE loop
		} while(option != 'F'); //WHILE not = to F... when choose this option we break out of the loop
		System.out.println("Thank you!");
	}
	
}
