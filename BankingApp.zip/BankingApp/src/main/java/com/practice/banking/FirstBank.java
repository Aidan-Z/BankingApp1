package com.practice.banking;

public class FirstBank {

	public static void main(String[] args) {
		
		//Creating a new object
		Account john = new Account("John Grey", "Z00441"); 
	// 1) "Account" is Object OF TYPE "Account"
	// 2) "john" is the name OF THE Object
	// 3) Then do "new object OF TYPE Account"
	// 4) Feeding string variables INTO Object
		
		john.showMenu(); //Call account by "john" (name of account) and call "showMenu" function which is main function that allows to access other functions
	}

}
